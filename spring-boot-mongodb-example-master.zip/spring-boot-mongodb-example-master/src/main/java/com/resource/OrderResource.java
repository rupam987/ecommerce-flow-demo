package com.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.document.Inventory;
import com.document.Order;
import com.document.OrderHistory;
import com.repository.InventoryRepository;
import com.repository.OrderHistoryRepository;
import com.repository.OrderRepository;

@RestController
@RequestMapping("/rest/orders")
public class OrderResource {

	@Autowired
    private OrderRepository orderRepository;
	
	@Autowired
    private InventoryRepository invRepository;
	
	@Autowired
    private OrderHistoryRepository ordHisRepository;

    @GetMapping("/{accId}")
    public ResponseEntity<?> getAllOrders(@PathVariable Long accId) {
        return new ResponseEntity<>(orderRepository.findAllOrders(accId),HttpStatus.OK);
    }
    
    @PostMapping("/")
    public ResponseEntity<?> placeOrder(@RequestBody Order order){
    	boolean isNotOrdered=false;
    	if(order!=null){
    		for(Inventory item : order.getItemList()){
    			if(item.getQuantity()>(invRepository.findCountOfItem(item.getId()))){
    				isNotOrdered=true;
    				return new ResponseEntity<>("Your order item is short of quantity",HttpStatus.OK);

    			}
    		}
    		if(!isNotOrdered){
    			Order orderBooked=orderRepository.save(order);
    			//entry in history table also
    			OrderHistory ordHistory = saveInOrderHistory(order);
    			ordHisRepository.save(ordHistory);
    			return new ResponseEntity<>("Your order(s) with ID: "+orderBooked.getId()+" has been placed successfully",HttpStatus.OK);
    		}
    		else
        		return new ResponseEntity<>("Your order was not placed",HttpStatus.CONFLICT);
    	}else
    		return new ResponseEntity<>("Your order was not placed",HttpStatus.CONFLICT);

    }

	private OrderHistory saveInOrderHistory(Order order) {
		OrderHistory orderHis=new OrderHistory();
		orderHis.setAccount(order.getAccount());
		orderHis.setOrderDate(order.getOrderDate());
		//setting list of items and all others
		return orderHis;
	}
}
