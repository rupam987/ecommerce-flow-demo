package com.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.document.Account;
import com.dto.LoginDto;
import com.repository.AccountRepository;

@RestController
@RequestMapping("/rest/users")
public class AccountResource {

	@Autowired
    private AccountRepository accRepository;


    @GetMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDto loginDto) {
    	if(loginDto!=null){
    		Account user=accRepository.findByUserName(loginDto.getUserName());
    		if(user!=null){
    			if(user.getPassword().equals(loginDto.getPassword())){
    				return new ResponseEntity<>("Logged-In successfully",HttpStatus.OK); 
    			}else{
    				return new ResponseEntity<>("Please specify a correct password",HttpStatus.OK); 
    			}
    		}else{
    			return new ResponseEntity<>("User Doesnot Exists",HttpStatus.OK); 
    		}
    	}else
    		return new ResponseEntity<>("Please specify username and password",HttpStatus.OK);
    }
}
