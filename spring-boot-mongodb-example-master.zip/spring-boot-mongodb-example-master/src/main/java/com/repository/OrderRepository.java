package com.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;

import com.document.Order;

public interface OrderRepository extends MongoRepository<Order, Long> {

	@Query("select o from Order o where o.account.id=:accId")
	List<Order> findAllOrders(@Param("accId") Long accId);

}
