package com.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.document.Order;
import com.document.OrderHistory;

public interface OrderHistoryRepository extends MongoRepository<OrderHistory, Long> {

}
