package com.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.document.Account;

public interface AccountRepository extends MongoRepository<Account, Integer> {

	Account findByUserName(String userName);
}
