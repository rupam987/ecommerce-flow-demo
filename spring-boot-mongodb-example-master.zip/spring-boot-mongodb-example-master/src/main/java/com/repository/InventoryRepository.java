package com.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;

import com.document.Inventory;

public interface InventoryRepository extends MongoRepository<Inventory, Long> {

	@Query("select count(i) from Inventory i where i.id=:itemId")
	Long findCountOfItem(@Param("itemId") Long itemId);

}
