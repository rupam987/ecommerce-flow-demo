package com.document;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="order")
public class Order implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
    private Long id;
	private Date orderDate;
	private Double totalAmt;
	private String shipAddress;
	private String paymentId;
	
	@ManyToOne
	private Account account;
	
	/*@OneToOne
	private Inventory item;*/
	
	@OneToMany(mappedBy="order")
	private List<Inventory> itemList;
	
	
	
	public List<Inventory> getItemList() {
		return itemList;
	}
	public void setItemList(List<Inventory> itemList) {
		this.itemList = itemList;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
	/*public Inventory getItem() {
		return item;
	}
	public void setItem(Inventory item) {
		this.item = item;
	}*/
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Double getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(Double totalAmt) {
		this.totalAmt = totalAmt;
	}
	public String getShipAddress() {
		return shipAddress;
	}
	public void setShipAddress(String shipAddress) {
		this.shipAddress = shipAddress;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	
}
