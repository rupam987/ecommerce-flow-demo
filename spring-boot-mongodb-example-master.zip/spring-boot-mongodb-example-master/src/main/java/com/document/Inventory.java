package com.document;

import java.io.Serializable;

import javax.persistence.ManyToOne;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="inventory")
public class Inventory implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
    private Long id;
	private String itemName;
	private String itemDesc;
	private Long quantity;
	private Double price;

	@ManyToOne
	private Order order;
	
	public Inventory(Long id, String itemName, String itemDesc, Long quantity, Double price) {
		this.id = id;
		this.itemName = itemName;
		this.itemDesc = itemDesc;
		this.quantity = quantity;
		this.price = price;
	}
	
	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public Long getQuantity() {
		return quantity;
	}
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	
	
}
