package com.configuration;

import com.document.Account;
import com.document.Inventory;
import com.repository.AccountRepository;
import com.repository.InventoryRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@EnableMongoRepositories(basePackages={"com.repository"})
@Configuration
public class MongoDBConfig {


    @Bean
    CommandLineRunner commandLineRunner(AccountRepository userRepository) {
        return strings -> {
            userRepository.save(new Account(1L, "Ram", "ram@gmail.com", "9874563210", "bangalore", "ram123", "ram@123"));
            userRepository.save(new Account(2L, "Sam", "sam@gmail.com", "7125789630", "Mumbai", "sam123","sam@123"));
            
        };
    }
    
    @Bean
    CommandLineRunner commandLineRunner(InventoryRepository invRepository) {
        return strings -> {
        	invRepository.save(new Inventory(1L, "TV", "32 inch Micromax", 60L, 25000.0));
        	invRepository.save(new Inventory(1L, "Refrigerator", "192L Whirlpool", 60L, 12000.0));
            
        };
    }

}
